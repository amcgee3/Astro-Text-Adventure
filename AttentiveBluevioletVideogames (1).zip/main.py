import random
import os, sys
import time

# Output Manipulation

black = "\033[0;30m"
red = "\033[0;31m"
green = "\033[0;32m"
yellow = "\033[0;33m"
blue = "\033[0;34m"
magenta = "\033[0;35m"
cyan = "\033[0;36m"
white = "\033[0;37m"
bright_black = "\033[0;90m"
bright_red = "\033[0;91m"
bright_green = "\033[0;92m"
bright_yellow = "\033[0;93m"
bright_blue = "\033[0;94m"
bright_magenta = "\033[0;95m"
bright_cyan = "\033[0;96m"
bright_white = "\033[0;97m"

def clear(): # Will clear the results box to save space/memory
  os.system('clear')
def sp(message): # Slow print 
  delay = 0.04
  display = message
  for letter in display:
    sys.stdout.write(letter)
    sys.stdout.flush()
    time.sleep(delay)
  print() # Prints out the letters in a string 

# Player info

class player:
  name = 'none'
  ship = 'none'
  money = 100
  armour = 'none'
  inventory = ['basic ship']
  mission = 'Explore and upgrade your ship'
  life_points = 300
  collector_level = 1

  # Get methods

  def ship_check(self):
    sp(self.ship)
  
  def money_check(self):
    money = self.money
    sp('You currently have: ' + str(self.money) + ' credits')

  def armour_check(self):
    sp(self.armour)
  
  def inventory_check(self):
    for z in range(0, len(self.inventory)):
      sp(self.inventory[z])
  
  def mission_check(self):
    sp(self.mission)
  
  def life_check(self):
    return self.life_points

  def armour_check(self):
    sp(self.armour)
  
  def level_check(self):
    sp(self.collector_level)
  
  def check_all(self):
    sp(self.name)
    sp('ship: ' + self.ship)
    sp('credits: ' + str(self.money))
    sp('armour: ' + self.armour)
    sp('inventory: ' + str(self.inventory))
    sp('mission: ' + self.mission)
    sp('collector_lvl: ' + str(self.collector_level))
    time.sleep(3)
    clear()

  # Mutator Methods

  def ship_update(self, ship):
    temp = self.ship
    self.ship = ship
    self.inventory.append(temp)
  
  def money_plus(self, amount):
    self.money = self.money + amount
  
  def money_minus(self, amount):
    self.money = self.money - amount
  
  def armour_from_invent(self, item_name):
    if item_name in self.inventory:
      self.armour = item_name
      sp('You have equipped: ' + item_name)
    else:
      sp('There was nothing to equip')

  def ship_from_invent(self, item_name):
    if item_name in self.inventory:
      self.ship = item_name
      sp('You have equipped: ' + item_name)
      self.inventory.remove(item_name)
    else:
      sp('There was nothing to equip')
  
  def item_from_invent(self, item_name):
    if item_name == 'repair kit':
      self.life_points = self + 150
      self.inventory.remove(item_name)
    if item_name == 'repaif kit+':
      self.life_points = self + 600
      self.inventory.remove(item_name)
    if item_name == 'repair kit++':
      self.life_points = self + 1500
      self.inventory.remove(item_name)
      
  def level_up(self):
    self.collector_level = self + 1
    self.life_points = self + 200

  
player1 = player()

# Enemy info for random encounters

enemies = ['Bounty Hunter', 'Cleaner', 'Upgraded Cleaner', 'Elite Cleaner', 'Evil Space explorer', 'Unknown Species']
lp = [100, 100, 50, 150, 200, 75, 250, 300, 275, 225, 125, 175, 300, 300, 200] # Max life point range area1
lp2 = [300, 325, 350, 375, 400, 425, 450, 475, 500] # Max life point range area2
lp3 = [500, 525, 550, 575, 600, 625, 650, 675, 700, 750, 800, 1000] # Max life point range area3
emax1 = [25, 50, 75, 100, 125, 150, 175, 200] # Max hit for attack ranges in area1
emax2 = [200, 225, 250, 300, 325, 375, 400, 500] # Max hit for attack ranges in area2
emax3 = [500, 550, 600, 650, 700, 750, 800, 900, 1000] # Max hit for attack ranges in area3

# Shop Info

shop_one = ['Cruizer1', 'Speeder1', 'Bruizer1', 'repair kit', 'smoke rocket', 'armour1'] # Note these are area shops
shop_two = ['Cruizer2', 'Speeder2', 'Bruizer2', 'repair kit+', 'collector upgrade', 'armour2']
shop_three = ['Cruizer3', 'Speeder3', 'Bruizer3', 'repair kit++', 'collector upgrade', 'armour3']

# Shop 1

def shop1():
  sp("Welcome to Shop 1, here are the items sold here.")
  for x in range(0, len(shop_one)):
    sp(str(x) + '. ' + shop_one[x])
  
  sp('What would you like to buy?')
  option = int(input())
  
  if option == 0:
    player1.money_check()
    sp('Cruizer1 costs 450 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(450)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        player1.ship_update('Cruizer1')
      else:
        player1.inventory.append('Cruizer1')
  elif option == 1:
    player1.money_check()
    sp('Speeder1 costs 200 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(200)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        ship.update('Speeder1')
      else:
        player1.inventory.append('Speeder1')
  elif option == 2:
    player1.money_check()
    sp('Bruiser1 costs 325 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(325)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        ship.update('Bruiser1')
      else:
        player1.inventory.append('Bruiser1')
  elif option == 3:
    player1.money_check()
    sp('Repair Kit costs 50 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(50)
      player1.inventory.append('repair kit')
  elif option == 4:
    player1.money_check()
    sp('Smoke Rocket costs 100 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(50)
      player1.inventory.append('smoke rocket')
  elif option == 5:
    player1.money_check()
    sp('Armour1 costs 250 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(250)
      player1.inventory.append('armour1')
  else:
    sp("Invalid entry, try again")
    time.sleep(3.0) # Delay so the user gets to see error message.
    clear()
    
    sp("Welcome to Shop 1, here are the items sold here.")
    for x in range(0, len(shop_one)):
      sp(str(x) + '. ' + shop_one[x])
    sp('What would you like to buy?')
    option = int(input())

# Shop 2
def shop2():
  sp("Welcome to Shop 2, here are the items sold here.")
  for x in range(0, len(shop_two)):
    sp(str(x) + '. ' + shop_two[x])
  
  sp('What would you like to buy?')
  option = int(input())
  
  if option == 0:
    player1.money_check()
    sp('Cruizer2 costs 900 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(900)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        player1.ship_update('Cruizer2')
      else:
        player1.inventory.append('Cruizer2')
  elif option == 1:
    player1.money_check()
    sp('Speeder2 costs 600 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(600)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        ship.update('Speeder2')
      else:
        player1.inventory.append('Speeder2')
  elif option == 2:
    player1.money_check()
    sp('Bruiser2 costs 975 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(975)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        ship.update('Bruiser2')
      else:
        player1.inventory.append('Bruiser2')
  elif option == 3:
    player1.money_check()
    sp('Repair Kit+ costs 450 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(150)
      player1.inventory.append('repair kit+')
  elif option == 4:
    player1.money_check()
    sp('Collector Upgrade costs 1500 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(1500)
      player1.collector_level = self + 1
      sp('You leveled up your collector, your new level is: ', player1.level_check())
  elif option == 5:
    player1.money_check()
    sp('Armour2 costs 750 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(750)
      player1.inventory.append('armour2')
  else:
    sp("Invalid entry, try again")
    time.sleep(3.0) # Delay so the user gets to see error message.
    clear()
    
    sp("Welcome to Shop 1, here are the items sold here.")
    for x in range(0, len(shop_two)):
      sp(str(x) + '. ' + shop_two[x])
    sp('What would you like to buy?')
    option = int(input())

# Shop 3
def shop3():
  sp("Welcome to Shop 3, here are the items sold here.")
  for x in range(0, len(shop_three)):
    sp(str(x) + '. ' + shop_three[x])
  
  sp('What would you like to buy?')
  option = int(input())
  
  if option == 0:
    player1.money_check()
    sp('Cruizer3 costs 2700 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(2700)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        player1.ship_update('Cruizer3')
      else:
        player1.inventory.append('Cruizer3')
  elif option == 1:
    player1.money_check()
    sp('Speeder3 costs 1800 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(1800)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        ship.update('Speeder3')
      else:
        player1.inventory.append('Speeder3')
  elif option == 2:
    player1.money_check()
    sp('Bruiser3 costs 3000 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(3000)
      sp('Would you like to equip it now?')
      option = input()
      if option == 'y' or option == 'yes':
        ship.update('Bruiser3')
      else:
        player1.inventory.append('Bruiser3')
  elif option == 3:
    player1.money_check()
    sp('Repair Kit++ costs 1000 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(1000)
      player1.inventory.append('repair kit++')
  elif option == 4:
    player1.money_check()
    sp('Collector upgrade costs 3000 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(3000)
      player1.collector_level = self + 1
      sp('You leveled up your collector, your new level is: ', player1.level_check())
  elif option == 5:
    player1.money_check()
    sp('Armour1 costs 250 credits. Would you like to buy it? (y/n)')
    option = input()
    if option == 'y' or option == 'yes':
      player1.money_minus(250)
      player1.inventory.append('armour1')
  else:
    sp("Invalid entry, try again")
    time.sleep(3.0) # Delay so the user gets to see error message.
    clear()
    
    sp("Welcome to Shop 3, here are the items sold here.")
    for x in range(0, len(shop_three)):
      sp(str(x) + '. ' + shop_three[x])
    sp('What would you like to buy?')
    option = int(input())

# Player Combat Mechanics

player_exp = 0
damage_reduction = 0 # Enemy damage reduced by armour
damage_output = player1.collector_level * 25 # How hard player can hit without ship bonuses
armour_boost = 0 # Damage boost when wearing armour
collector_boost = 0 # Boost to collection when using certain ships

# Player attack damage

if player1.ship == 'basic ship':
  damage_output = damage_output + 100
  player_attack = random.randint(0, damage_output)
elif player1.ship == 'cruizer1':
  damage_output = damage_output + 250
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction + 150
  collection_boost = 'no'
elif player1.ship == 'speeder1':
  damage_output = damage_output + 150
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction
  collection_boost = 'yes' # This has a seperate calculation. This is mostly for code_reading
elif player1.ship == 'bruizer1':
  damage_output = damage_output + 400
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction 
  collection_boost = 'no'
elif player1.ship == 'cruizer2':
  damage_output = damage_output + 500
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction + 300
  collection_boost = 'no'
elif player1.ship == 'speeder2':
  damage_output = damage_output + 400
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction
  collection_boost = 'yes' # This has a seperate calculation. This is mostly for code_reading
elif player1.ship == 'bruizer2':
  damage_output = damage_output + 800
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction
  collection_boost = 'no'
elif player1.ship == 'cruizer3':
  damage_output = damage_output + 1000
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction + 600
  collection_boost = 'no'
elif player1.ship == 'speeder3':
  damage_output = damage_output + 800
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction
  collection_boost = 'yes' # This has a seperate calculation. This is mostly for code_reading
elif player1.ship == 'bruizer2':
  damage_output = damage_output + 1600
  player_attack = random.randint(0, damage_output)
  damage_reduction = damage_reduction
  collection_boost = 'no'

# Game Start

sp(yellow + 'Welcome to Astro Text Adventure.')
sp(blue + 'Enter your name: ')
player1.name = input()
sp(yellow + 'Your journey begins...')
time.sleep(1.5)
sp('Now!')
time.sleep(1.5)
clear()

player1.check_all()
sp(white + 'You need a ship if you want to navigate through space')
sp('Would you like to equip your basic ship? (y/n)')
option = input()
if option == 'y' or option == 'yes':
  player1.ship_from_invent('basic ship')
clear()

sp('When you reach level 10 you will unlock a new area and new items.')

while player1.life_points > 0 and player1.collector_level < 10:
  
  if player1.ship == 'basic ship':
    damage_output = damage_output + 100
    player_attack = random.randint(0, damage_output)
  elif player1.ship == 'cruizer1':
    damage_output = damage_output + 250
    player_attack = random.randint(0, damage_output)
    damage_reduction = damage_reduction + 150
    collection_boost = 'no'
  elif player1.ship == 'speeder1':
    damage_output = damage_output + 150
    player_attack = random.randint(0, damage_output)
    damage_reduction = damage_reduction
    collection_boost = 'yes' # This has a seperate calculation. This is mostly for code_reading
  elif player1.ship == 'bruizer1':
    enemy_attack = random.randint(0, enemy_damage)
    sp('Your enemy attacks and does: ' + str(enemy_attack) + ' damage')
    player1.life_points = player1.life_points - enemy_attack
  
  if player_exp % 85 == 0:
    player1.level_up

  sp('What would you like to do? (collect or fight)')
  option = input()
  if option == 'collect' or option == 'Collect':
    scavenge = ['small space rubble', 'small space rubble', 'small space rubble', 'small space rubble', 'small space rubble', 'medium space rubble', 'medium space rubble', 'medium space rubble', 'medium space rubble', 'medium space rubble', 'large rubble', 'large rubble', 'large rubble', 'asteroid derbris', 'asteroid derbris']
    if collector_boost == 'yes':
      num_items = random.randint(1, 5)
      for x in range(0, num_items):
        found = random.choice(scavenge)
        player1.inventory.append(found)
        sp('You find: ' + found)
    else:
      num_items = random.randint(1, 3)
      for x in range(0, num_items):
        found = random.choice(scavenge)
        player1.inventory.append(found)
        sp('You find: ' + found)
  if option == 'fight' or option == 'Fight':
    enemies = ['Bounty Hunter', 'Cleaner', 'Upgraded Cleaner', 'Elite Cleaner', 'Evil Space explorer', 'Unknown Species']
    lp = [100, 100, 50, 150, 200, 75, 250, 300, 275, 225, 125, 175, 300, 300, 200]
    emax1 = [25, 50, 75, 100, 125, 150, 175, 200]
    enemy = random.choice(enemies)
    enemy_hp = random.choice(lp)
    enemy_damage = random.choice(emax1)
    sp('You run into: ' + enemy + ' with ' + str(enemy_hp) + ' hp')
    while player.life_points > 0 and enemy_hp > 0:
      
      player1.life_check
      enemy_hp = enemy_hp
      sp('Attack or use item?')
      option = input()

      if option == 'attack' or 'Attack':
        player1.life_check()
        enemy_hp = enemy_hp

        player_attack = random.randint(0, damage_output)
        enemy_damage = random.choice(emax1)

        enemy_hp = enemy_hp - player_attack
        sp('You hit your enemy for: ' + str(player_attack) + ' damage')
        player.life_points = player.life_points - enemy_damage
        sp('You enemy hits you for: ' + str(enemy_damage) + ' damage')

        if enemy_hp == 0:
          exp = enemy_hp/4
          player_exp = player_exp + exp
          sp('You gain: ' + str(exp))
  if player1.life_points == 0:
    break
  else:
    player1.life_check()

sp("Game Over, Thank you for playing.")
sp("We planned for this to be bigger but due to a lack of time we had to stop here.")

sp('''More than 500,000 pieces of debris, or “space junk,” are tracked as they orbit the Earth. They all travel at speeds up to 17,500 mph, fast enough for a relatively small piece of orbital debris to damage a satellite or a spacecraft.''')

sp('''Debris avoidance maneuvers are planned when the probability of collision from a conjunction reaches limits set in the space shuttle and space station flight rules. If the probability of collision is greater than 1 in 100,000, a maneuver will be conducted if it will not result in significant impact to mission objectives. If it is greater than 1 in 10,000, a maneuver will be conducted unless it will result in additional risk to the crew.''')

